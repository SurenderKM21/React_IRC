package com.sims.CampusMate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sims.CampusMate.model.Address;
import com.sims.CampusMate.service.AddressService;

@RestController
public class AddressController 
{
    @Autowired
    private AddressService as;

    // @PostMapping(post"/addres")
    // public ResponseEntity<Address> addAddress(@RequestBody Address address) {
    //     Address newAddress = as.createAddress(address);
    //     return new ResponseEntity<>(newAddress, HttpStatus.CREATED);
    // }   

    @PostMapping("/postadd")
    public ResponseEntity<String> add(@RequestBody Address u)
    {
        as.createAddress(u);
        return new ResponseEntity<>("New Address Added Successfully",HttpStatus.CREATED);
    }

    @GetMapping("/getaddress")
    public ResponseEntity<?> getAddress()
    {
        try{
        return new ResponseEntity<>(as.getAddress(), HttpStatus.CREATED);
    } 
    catch(Exception e)
    {
        return new ResponseEntity<>(HttpStatus.IM_USED);
    }
}
}
