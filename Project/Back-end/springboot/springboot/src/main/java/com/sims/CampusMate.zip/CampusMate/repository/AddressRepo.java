package com.sims.CampusMate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sims.CampusMate.model.*;

public interface AddressRepo extends JpaRepository<Address, Integer> {
    // additional methods if required
}